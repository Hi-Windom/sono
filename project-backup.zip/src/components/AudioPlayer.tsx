import React from 'react';
import { formatTime } from '../utils/audioUtils';

interface AudioPlayerProps {
  isPlaying: boolean;
  currentTime: number;
  duration: number;
  playMode: 'original' | 'processed';
  onPlay: () => void;
  onPause: () => void;
  onSeek?: (time: number) => void;
  onTogglePlayMode?: () => void;
}

export function AudioPlayer({ 
  isPlaying, 
  currentTime, 
  duration, 
  playMode,
  onPlay, 
  onPause, 
  onSeek,
  onTogglePlayMode
}: AudioPlayerProps) {
  return (
    <div className="bg-gradient-to-br from-primary/80 to-dark/80 rounded-2xl p-6 border border-secondary/20">
      <div className="flex flex-col gap-4">
        <div className="flex items-center justify-center gap-4">
          {onTogglePlayMode && (
            <button
              onClick={onTogglePlayMode}
              className="flex items-center gap-2 px-4 py-2 bg-secondary/20 hover:bg-secondary/30 text-secondary rounded-lg transition text-sm font-medium"
            >
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7h12m0 0l-4-4m4 4l-4 4m0 6H4m0 0l4 4m-4-4l4-4" />
              </svg>
              {playMode === 'original' ? '播放原始' : '播放修复'}
            </button>
          )}
          
          <button
            onClick={isPlaying ? onPause : onPlay}
            className="w-16 h-16 rounded-full flex items-center justify-center transition-all bg-gradient-to-r from-secondary to-accent hover:scale-105 shadow-lg shadow-secondary/30"
          >
            {isPlaying ? (
              <svg className="w-7 h-7 text-white" fill="currentColor" viewBox="0 0 24 24">
                <path d="M6 4h4v16H6V4zm8 0h4v16h-4V4z" />
              </svg>
            ) : (
              <svg className="w-7 h-7 text-white ml-1" fill="currentColor" viewBox="0 0 24 24">
                <path d="M8 5v14l11-7z" />
              </svg>
            )}
          </button>
        </div>
        
        {duration > 0 && (
          <div className="flex items-center gap-4">
            <span className="text-gray-400 text-sm w-12 text-right">
              {formatTime(currentTime)}
            </span>
            <div className="flex-1 h-2 bg-gray-700 rounded-full overflow-hidden">
              <div 
                className="h-full bg-gradient-to-r from-secondary to-accent transition-all duration-100"
                style={{ width: `${(currentTime / duration) * 100}%` }}
              />
            </div>
            <span className="text-gray-400 text-sm w-12">
              {formatTime(duration)}
            </span>
          </div>
        )}
      </div>
    </div>
  );
}
