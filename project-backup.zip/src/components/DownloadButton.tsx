import React from 'react';

interface DownloadButtonProps {
  onDownload?: () => void;
  disabled: boolean;
  hasBeenProcessed: boolean;
  repairResult?: {
    issues_found: string[];
    original_sample_rate: number;
    output_sample_rate: number;
    output_bit_depth: number;
    duration: number;
    channels: number;
  } | null;
  audioFileName?: string;
  originalFileSize?: number;
}

export function DownloadButton({ onDownload, disabled, hasBeenProcessed, repairResult, audioFileName, originalFileSize }: DownloadButtonProps) {
  const repairedFileName = audioFileName
    ? `${audioFileName.replace(/\.[^/.]+$/, '')}_repaired.wav`
    : 'repaired_audio.wav';

  const estimatedSize = repairResult
    ? ((repairResult.duration * repairResult.output_sample_rate * repairResult.channels * (repairResult.output_bit_depth / 8)) / (1024 * 1024)).toFixed(2)
    : null;

  return (
    <div>
      <button
        onClick={onDownload}
        disabled={disabled}
        className={`w-full py-4 px-6 rounded-xl font-bold text-lg flex items-center justify-center gap-3 transition-all ${
          disabled
            ? 'bg-gray-700 text-gray-500 cursor-not-allowed'
            : 'bg-gradient-to-r from-accent to-secondary text-white hover:scale-[1.02] shadow-lg shadow-accent/30'
        }`}
      >
        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
        </svg>
        {hasBeenProcessed ? '导出修复音频' : '请先修复音频'}
      </button>

      {hasBeenProcessed && repairResult && (
        <div className="mt-3 p-3 bg-black/20 rounded-lg space-y-1">
          <div className="flex justify-between text-xs">
            <span className="text-gray-400">文件名</span>
            <span className="text-white truncate ml-4 max-w-[200px]" title={repairedFileName}>{repairedFileName}</span>
          </div>
          <div className="flex justify-between text-xs">
            <span className="text-gray-400">文件大小</span>
            <span className="text-white">{estimatedSize ? `${estimatedSize} MB` : '-'}</span>
          </div>
          <div className="flex justify-between text-xs">
            <span className="text-gray-400">采样率</span>
            <span className="text-cyan-400">{repairResult.output_sample_rate / 1000} kHz</span>
          </div>
          <div className="flex justify-between text-xs">
            <span className="text-gray-400">位深</span>
            <span className="text-cyan-400">{repairResult.output_bit_depth} bit</span>
          </div>
          <div className="flex justify-between text-xs">
            <span className="text-gray-400">声道</span>
            <span className="text-white">{repairResult.channels === 1 ? '单声道' : '立体声'}</span>
          </div>
        </div>
      )}
    </div>
  );
}
