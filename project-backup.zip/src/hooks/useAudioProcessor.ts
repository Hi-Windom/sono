import { useRef, useState, useCallback, useEffect } from 'react';
import { AIRepairParams, defaultAIRepairParams, detectAudioIssues, repairModes, RepairMode } from '../utils/advancedAudioProcessing';
import { AISongDetectionResult } from '../utils/aiSongChecker';
import { loadSettings, saveSettings, resetSettings as resetStoredSettings } from '../utils/settingsStorage';
import { parseWavHeader, WavInfo } from '../utils/wavParser';
import {
  uploadAudio,
  detectAudio,
  repairAudio,
  pollProgress,
  getPreviewUrl,
  getDownloadUrl,
  mapDetectionResult,
  ProcessingOptions,
} from '../services/backendApi';

export interface AudioAnalysis {
  spectralFlatness: number;
  dynamicRange: number;
  stereoBalance: number;
  peakLevel: number;
  issues: string[];
}

export type PlayMode = 'original' | 'processed';

export type { ProcessingOptions };

export const defaultProcessingOptions: ProcessingOptions = {
  sampleRate: 48000,
  bitDepth: 24,
};

function createRepairWorker(): Worker {
  return new Worker(new URL('../workers/audioRepairWorker.ts', import.meta.url));
}

export function useAudioProcessor() {
  const savedSettings = loadSettings();

  const [audioFile, setAudioFile] = useState<File | null>(null);
  const [audioBuffer, setAudioBuffer] = useState<AudioBuffer | null>(null);
  const [processedAudioBuffer, setProcessedAudioBuffer] = useState<AudioBuffer | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [isProcessing, setIsProcessing] = useState(false);
  const [processingProgress, setProcessingProgress] = useState(0);
  const [processingStep, setProcessingStep] = useState('');
  const [params, setParams] = useState<AIRepairParams>(savedSettings.aiRepairParams);
  const [audioAnalysis, setAudioAnalysis] = useState<AudioAnalysis | null>(null);
  const [selectedMode, setSelectedMode] = useState<string>(savedSettings.selectedMode);
  const [playMode, setPlayMode] = useState<PlayMode>('original');
  const [processingOptions, setProcessingOptionsState] = useState<ProcessingOptions>(savedSettings.exportOptions);
  const [originalAIDetection, setOriginalAIDetection] = useState<AISongDetectionResult | null>(null);
  const [processedAIDetection, setProcessedAIDetection] = useState<AISongDetectionResult | null>(null);
  const [hasBeenProcessed, setHasBeenProcessed] = useState(false);
  const [backendAvailable, setBackendAvailable] = useState(false);
  const [backendDiag, setBackendDiag] = useState<string>('未检测');
  const [taskId, setTaskId] = useState<string | null>(null);
  const taskIdRef = useRef<string | null>(null);
  const [wavInfo, setWavInfo] = useState<WavInfo | null>(null);
  const [repairResult, setRepairResult] = useState<{
    issues_found: string[];
    original_sample_rate: number;
    output_sample_rate: number;
    output_bit_depth: number;
    duration: number;
    channels: number;
  } | null>(null);

  const audioContextRef = useRef<AudioContext | null>(null);
  const sourceNodeRef = useRef<AudioBufferSourceNode | null>(null);
  const gainNodeRef = useRef<GainNode | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const startTimeRef = useRef(0);
  const pausedAtRef = useRef(0);
  const animationFrameRef = useRef<number>();
  const isPlayingRef = useRef(false);
  const workerRef = useRef<Worker | null>(null);

  useEffect(() => {
    fetch('/health', { signal: AbortSignal.timeout(5000) })
      .then(res => {
        setBackendAvailable(res.ok);
        console.log(`[useAudioProcessor] 初始健康检查: ${res.ok ? '后端可用' : '后端不可用'}`);
      })
      .catch(() => {
        setBackendAvailable(false);
        console.log('[useAudioProcessor] 初始健康检查: 后端不可用(请求失败)');
      });
  }, []);

  useEffect(() => {
    saveSettings({
      aiRepairParams: params,
      exportOptions: processingOptions,
      stemSettings: {
        vocalGain: 0,
        instrumentalGain: 0,
        vocalBalance: 0,
      },
      selectedMode,
    });
  }, [params, processingOptions, selectedMode]);

  useEffect(() => {
    return () => {
      if (workerRef.current) {
        workerRef.current.terminate();
        workerRef.current = null;
      }
    };
  }, []);

  const getAudioContext = useCallback(() => {
    if (!audioContextRef.current) {
      audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
      analyserRef.current = audioContextRef.current.createAnalyser();
      analyserRef.current.fftSize = 256;
    }
    return audioContextRef.current;
  }, []);

  const stopPlaying = useCallback(() => {
    if (sourceNodeRef.current) {
      try { sourceNodeRef.current.stop(); } catch {}
      sourceNodeRef.current.disconnect();
      sourceNodeRef.current = null;
    }
    if (animationFrameRef.current) {
      cancelAnimationFrame(animationFrameRef.current);
    }
    isPlayingRef.current = false;
    setIsPlaying(false);
  }, []);

  const loadAudioFile = useCallback(async (file: File) => {
    stopPlaying();
    setAudioFile(file);

    const context = getAudioContext();
    const arrayBuf = await file.arrayBuffer();
    const wavHeaderInfo = parseWavHeader(arrayBuf.slice(0, 44 + 4096));
    setWavInfo(wavHeaderInfo);
    const buffer = await context.decodeAudioData(arrayBuf);

    setAudioBuffer(buffer);
    setProcessedAudioBuffer(null);
    setDuration(buffer.duration);
    setCurrentTime(0);
    pausedAtRef.current = 0;
    setOriginalAIDetection(null);
    setProcessedAIDetection(null);
    setHasBeenProcessed(false);
    setPlayMode('original');
    setTaskId(null);
    taskIdRef.current = null;
    setRepairResult(null);
    setBackendAvailable(false);

    const analysis = detectAudioIssues(buffer);
    setAudioAnalysis(analysis);

    try {
      setProcessingStep('上传到后端...');
      setProcessingProgress(0);
      setIsProcessing(true);

      const uploadRes = await uploadAudio(file);
      const newTaskId = uploadRes.task_id;
      setTaskId(newTaskId);
      taskIdRef.current = newTaskId;
      setBackendAvailable(true);
      console.log(`[loadAudioFile] 上传成功 taskId=${newTaskId}`);
    } catch (err) {
      console.warn('[loadAudioFile] 上传失败:', err);
      setBackendAvailable(false);
    }

    setIsProcessing(false);
    setProcessingStep('');
    setProcessingProgress(0);
  }, [getAudioContext, stopPlaying]);

  const applyRepairMode = useCallback((mode: RepairMode) => {
    setSelectedMode(mode.name);
    setParams(mode.params);
  }, []);

  const updateParam = useCallback((key: keyof AIRepairParams, value: number) => {
    setParams(prev => ({ ...prev, [key]: value }));
  }, []);

  const updateProcessingOptions = useCallback((options: Partial<ProcessingOptions>) => {
    setProcessingOptionsState(prev => ({ ...prev, ...options }));
  }, []);

  const loadAudioFromUrl = useCallback(async (url: string, targetSampleRate?: number): Promise<AudioBuffer> => {
    const response = await fetch(url);
    const arrayBuffer = await response.arrayBuffer();

    if (targetSampleRate && targetSampleRate !== getAudioContext().sampleRate) {
      const tempContext = new OfflineAudioContext(1, 1, targetSampleRate);
      const tempBuffer = await tempContext.decodeAudioData(arrayBuffer);
      if (tempBuffer.sampleRate === targetSampleRate) {
        return tempBuffer;
      }
      const resampleLength = Math.ceil(tempBuffer.length * targetSampleRate / tempBuffer.sampleRate);
      const offlineCtx = new OfflineAudioContext(
        tempBuffer.numberOfChannels,
        resampleLength,
        targetSampleRate,
      );
      const source = offlineCtx.createBufferSource();
      source.buffer = tempBuffer;
      source.connect(offlineCtx.destination);
      source.start();
      return offlineCtx.startRendering();
    }

    const context = getAudioContext();
    return context.decodeAudioData(arrayBuffer);
  }, [getAudioContext]);

  const repairWithWorker = useCallback(async (
    buffer: AudioBuffer,
    repairParams: Partial<AIRepairParams>,
  ): Promise<AudioBuffer> => {
    if (workerRef.current) {
      workerRef.current.terminate();
    }

    const worker = createRepairWorker();
    workerRef.current = worker;

    const channelData: Float32Array[] = [];
    for (let ch = 0; ch < buffer.numberOfChannels; ch++) {
      channelData.push(new Float32Array(buffer.getChannelData(ch)));
    }

    const requestId = Date.now().toString();

    const result = await new Promise<Float32Array[]>((resolve, reject) => {
      worker.onmessage = (e: MessageEvent) => {
        const { type, ...data } = e.data;

        if (type === 'progress') {
          setProcessingProgress(0.1 + data.progress * 0.6);
          setProcessingStep(data.step);
        } else if (type === 'repair_complete') {
          resolve(data.channels);
        } else if (type === 'error') {
          reject(new Error(data.error));
        }
      };

      worker.onerror = (e) => {
        reject(new Error(e.message));
      };

      worker.postMessage({
        type: 'repair',
        data: {
          channels: channelData,
          sampleRate: buffer.sampleRate,
          params: repairParams,
          id: requestId,
        },
      });
    });

    worker.terminate();
    workerRef.current = null;

    const context = getAudioContext();
    const numChannels = result.length;
    const length = result[0].length;
    const repairedBuffer = context.createBuffer(numChannels, length, buffer.sampleRate);

    for (let ch = 0; ch < numChannels; ch++) {
      repairedBuffer.copyToChannel(result[ch], ch);
    }

    return repairedBuffer;
  }, [getAudioContext]);

  const encodeWavWithWorker = useCallback(async (
    buffer: AudioBuffer,
    bitDepth: 16 | 24 | 32,
  ): Promise<ArrayBuffer> => {
    if (workerRef.current) {
      workerRef.current.terminate();
    }

    const worker = createRepairWorker();
    workerRef.current = worker;

    const channelData: Float32Array[] = [];
    for (let ch = 0; ch < buffer.numberOfChannels; ch++) {
      channelData.push(new Float32Array(buffer.getChannelData(ch)));
    }

    const requestId = Date.now().toString();

    const wavData = await new Promise<ArrayBuffer>((resolve, reject) => {
      worker.onmessage = (e: MessageEvent) => {
        const { type, ...data } = e.data;

        if (type === 'encode_wav_complete') {
          resolve(data.wavData);
        } else if (type === 'error') {
          reject(new Error(data.error));
        }
      };

      worker.onerror = (e) => {
        reject(new Error(e.message));
      };

      worker.postMessage({
        type: 'encode_wav',
        data: {
          channels: channelData,
          sampleRate: buffer.sampleRate,
          bitDepth,
          id: requestId,
        },
      });
    });

    worker.terminate();
    workerRef.current = null;

    return wavData;
  }, []);

  const applySettings = useCallback(async () => {
    if (!audioBuffer) return;

    setIsProcessing(true);
    setProcessingProgress(0);
    setProcessingStep('准备修复...');

    const REPAIR_TERMINALS = new Set(['completed', 'error']);
    let backendRepairOk = false;
    const currentTaskId = taskIdRef.current;

    if (currentTaskId) {
      try {
        setBackendAvailable(true);
        setProcessingStep('提交修复任务...');
        setProcessingProgress(0.01);
        console.log(`[applySettings] 后端修复 taskId=${currentTaskId}`);

        await repairAudio(currentTaskId, params, processingOptions);

        const repairResult = await new Promise<import('../services/backendApi').ProgressEvent>((resolve, reject) => {
          pollProgress(
            currentTaskId,
            (event) => {
              setProcessingProgress(0.1 + event.progress * 0.85);
              setProcessingStep(event.step);
            },
            reject,
            resolve,
            REPAIR_TERMINALS,
          );
        });

        console.log(`[applySettings] 轮询结束 status=${repairResult.status}`);

        if (repairResult.status !== 'completed') {
          throw new Error(repairResult.error || `修复失败(status=${repairResult.status})`);
        }

        setProcessingStep('加载修复后音频...');
        setProcessingProgress(0.96);

        const previewUrl = getPreviewUrl(currentTaskId, 'repaired');
        const repairedBuffer = await loadAudioFromUrl(previewUrl, processingOptions.sampleRate);
        setProcessedAudioBuffer(repairedBuffer);
        setHasBeenProcessed(true);
        setPlayMode('processed');
        backendRepairOk = true;

        if (repairResult.repair_result) {
          setRepairResult(repairResult.repair_result);
        }

        setProcessingStep('完成!');
        setProcessingProgress(1);
      } catch (err) {
        const msg = err instanceof Error ? err.message : String(err);
        console.warn(`[applySettings] 后端修复失败: ${msg}`);
        setBackendAvailable(false);
        setProcessingStep(`后端修复失败: ${msg}`);
        await new Promise(r => setTimeout(r, 1500));
      }
    } else {
      console.warn('[applySettings] 无taskId, 尝试上传...');
      try {
        setProcessingStep('上传到后端...');
        const uploadRes = await uploadAudio(audioFile!);
        const newTaskId = uploadRes.task_id;
        setTaskId(newTaskId);
        taskIdRef.current = newTaskId;
        setBackendAvailable(true);
        console.log(`[applySettings] 上传成功 taskId=${newTaskId}, 重新调用applySettings`);

        setIsProcessing(false);
        setProcessingStep('');
        setProcessingProgress(0);
        return;
      } catch (uploadErr) {
        const msg = uploadErr instanceof Error ? uploadErr.message : String(uploadErr);
        console.warn(`[applySettings] 上传失败: ${msg}`);
        setBackendAvailable(false);
      }
    }

    if (!backendRepairOk) {
      try {
        setProcessingStep('使用浏览器端修复...');
        const { checkAISong } = await import('../utils/aiSongChecker');
        const { enhanceHighFrequencies } = await import('../utils/highFrequencyEnhancer');

        if (!originalAIDetection) {
          setOriginalAIDetection(checkAISong(audioBuffer));
        }

        setProcessingStep('应用音频修复(Worker线程)...');
        setProcessingProgress(0.05);

        const workerParams = {
          deClipping: params.deClipping,
          noiseReduction: params.noiseReduction,
          deCrackle: params.deCrackle,
          dePop: params.dePop,
          harmonicEnhance: params.harmonicEnhance,
          dynamicRange: params.dynamicRange,
          softness: params.softness,
          spatialEnhance: params.spatialEnhance,
          transientRepair: params.transientRepair,
        };

        let repaired = await repairWithWorker(audioBuffer, workerParams);

        if (params.deEssing > 0) {
          setProcessingStep('去齿音(三频段压缩)...');
          setProcessingProgress(0.7);
          repaired = await applyDeEssing(repaired, params.deEssing);
        }

        if (params.presenceBoost > 0) {
          setProcessingStep('临场感增强(三频段EQ)...');
          setProcessingProgress(0.78);
          repaired = await applyPresenceBoost(repaired, params.presenceBoost);
        }

        if (params.bassEnhance > 0) {
          setProcessingStep('低音增强(双频段)...');
          setProcessingProgress(0.82);
          repaired = await applyBassEnhance(repaired, params.bassEnhance);
        }

        setProcessingStep('重采样...');
        setProcessingProgress(0.85);

        const targetSampleRate = processingOptions.sampleRate;
        let finalBuffer: AudioBuffer;

        if (repaired.sampleRate !== targetSampleRate) {
          if (targetSampleRate === 96000) {
            setProcessingStep('96kHz高频增强重采样...');
            finalBuffer = await enhanceHighFrequencies(repaired, (progress) => {
              setProcessingProgress(0.85 + progress * 0.05);
            });
          } else {
            setProcessingStep(`重采样到 ${targetSampleRate / 1000} kHz...`);
            const targetLength = Math.ceil(repaired.length * (targetSampleRate / repaired.sampleRate));
            const offlineContext = new OfflineAudioContext(
              repaired.numberOfChannels,
              targetLength,
              targetSampleRate,
            );
            const source = offlineContext.createBufferSource();
            source.buffer = repaired;
            source.connect(offlineContext.destination);
            source.start();
            finalBuffer = await offlineContext.startRendering();
          }
        } else {
          finalBuffer = repaired;
        }

        setProcessingStep('AI检测分析...');
        setProcessingProgress(0.92);

        setProcessedAIDetection(checkAISong(finalBuffer));
        setProcessedAudioBuffer(finalBuffer);
        setHasBeenProcessed(true);
        setPlayMode('processed');
        setRepairResult({
          issues_found: ['浏览器端修复'],
          original_sample_rate: audioBuffer.sampleRate,
          output_sample_rate: finalBuffer.sampleRate,
          output_bit_depth: processingOptions.bitDepth,
          duration: finalBuffer.duration,
          channels: finalBuffer.numberOfChannels,
        });

        setProcessingStep('完成!');
        setProcessingProgress(1);
      } catch (browserErr) {
        console.error('[applySettings] 浏览器修复失败:', browserErr);
        setProcessingStep(`错误: ${browserErr instanceof Error ? browserErr.message : '未知错误'}`);
      }
    }

    setIsProcessing(false);
    setTimeout(() => {
      setProcessingStep('');
      setProcessingProgress(0);
    }, 2000);
  }, [audioBuffer, audioFile, params, processingOptions, originalAIDetection, loadAudioFromUrl, repairWithWorker]);

  const runAIDetection = useCallback(async () => {
    if (!audioBuffer) return;

    const currentTaskId = taskIdRef.current;
    const DETECT_TERMINALS = new Set(['detected', 'completed', 'error']);

    if (currentTaskId && backendAvailable) {
      try {
        setIsProcessing(true);
        setProcessingStep('AI检测原始音频...');
        setProcessingProgress(0);
        await detectAudio(currentTaskId, 'original');

        const detectResult = await new Promise<import('../services/backendApi').ProgressEvent>((resolve, reject) => {
          pollProgress(currentTaskId, (event) => {
            setProcessingProgress(event.progress);
            setProcessingStep(event.step);
            if (event.detection_result) {
              setOriginalAIDetection(mapDetectionResult(event.detection_result));
            }
          }, reject, resolve, DETECT_TERMINALS);
        });

        if (detectResult.detection_result) {
          setOriginalAIDetection(mapDetectionResult(detectResult.detection_result));
        }

        if (hasBeenProcessed && processedAudioBuffer) {
          setProcessingStep('AI检测修复后音频...');
          await detectAudio(currentTaskId, 'repaired');

          await new Promise<import('../services/backendApi').ProgressEvent>((resolve, reject) => {
            pollProgress(currentTaskId, (evt) => {
              if (evt.repaired_detection_result) {
                setProcessedAIDetection(mapDetectionResult(evt.repaired_detection_result));
              }
            }, reject, resolve, DETECT_TERMINALS);
          });
        }
      } catch (err) {
        console.warn('[runAIDetection] 后端检测失败, 降级本地:', err);
        const { checkAISong } = await import('../utils/aiSongChecker');
        setOriginalAIDetection(checkAISong(audioBuffer));
        if (hasBeenProcessed && processedAudioBuffer) {
          setProcessedAIDetection(checkAISong(processedAudioBuffer));
        }
      }
    } else {
      const { checkAISong } = await import('../utils/aiSongChecker');
      setOriginalAIDetection(checkAISong(audioBuffer));
      if (hasBeenProcessed && processedAudioBuffer) {
        setProcessedAIDetection(checkAISong(processedAudioBuffer));
      }
    }

    setIsProcessing(false);
    setProcessingStep('');
    setProcessingProgress(0);
  }, [audioBuffer, processedAudioBuffer, backendAvailable, hasBeenProcessed]);

  const resetParams = useCallback(() => {
    setParams(defaultAIRepairParams);
    setSelectedMode('全面修复');
    resetStoredSettings();
  }, []);

  const runBackendDiag = useCallback(async () => {
    const lines: string[] = [];
    lines.push(`时间: ${new Date().toLocaleTimeString()}`);
    lines.push(`页面URL: ${window.location.href}`);
    lines.push(`hostname: ${window.location.hostname}`);
    lines.push(`protocol: ${window.location.protocol}`);

    lines.push('');
    lines.push('--- /health 测试 ---');
    try {
      const t0 = performance.now();
      const res = await fetch('/health', { signal: AbortSignal.timeout(5000) });
      const t1 = performance.now();
      const text = await res.text();
      lines.push(`状态: ${res.status} ${res.statusText}`);
      lines.push(`耗时: ${Math.round(t1 - t0)}ms`);
      lines.push(`响应: ${text.substring(0, 200)}`);
    } catch (e: any) {
      lines.push(`失败: ${e?.message || e}`);
    }

    lines.push('');
    lines.push('--- /api/v1/upload 测试(有效WAV) ---');
    try {
      const wavBlob = createValidWavBlob(1, 44100, 0.5);
      const file = new File([wavBlob], 'diag.wav', { type: 'audio/wav' });
      const form = new FormData();
      form.append('file', file);
      const t0 = performance.now();
      const res = await fetch('/api/v1/upload', { method: 'POST', body: form, signal: AbortSignal.timeout(5000) });
      const t1 = performance.now();
      const text = await res.text();
      lines.push(`状态: ${res.status} ${res.statusText}`);
      lines.push(`耗时: ${Math.round(t1 - t0)}ms`);
      lines.push(`响应: ${text.substring(0, 200)}`);
    } catch (e: any) {
      lines.push(`失败: ${e?.message || e}`);
    }

    lines.push('');
    lines.push('--- 完整流程测试: 上传→检测→轮询(有效WAV) ---');
    try {
      const wavBlob = createValidWavBlob(1, 44100, 0.5);
      const file = new File([wavBlob], 'diag.wav', { type: 'audio/wav' });
      const form = new FormData();
      form.append('file', file);
      const uploadRes = await fetch('/api/v1/upload', { method: 'POST', body: form, signal: AbortSignal.timeout(10000) });
      const uploadData = await uploadRes.json();
      lines.push(`上传: status=${uploadRes.status} task_id=${uploadData.task_id}`);

      if (uploadData.task_id) {
        const detectRes = await fetch('/api/v1/detect', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ task_id: uploadData.task_id, type: 'original' }),
          signal: AbortSignal.timeout(5000),
        });
        const detectData = await detectRes.json();
        lines.push(`检测提交: status=${detectRes.status} msg=${detectData.message || detectData.detail}`);

        lines.push('轮询状态(最多30次, 每2秒):');
        for (let i = 0; i < 30; i++) {
          await new Promise(r => setTimeout(r, 2000));
          try {
            const statusRes = await fetch(`/api/v1/status/${uploadData.task_id}`, { signal: AbortSignal.timeout(5000) });
            const statusData = await statusRes.json();
            lines.push(`  [${i+1}] status=${statusData.status} progress=${statusData.progress?.toFixed?.(2) ?? statusData.progress} step=${statusData.step} err=${statusData.error || 'none'}`);
            if (['completed', 'detected', 'error'].includes(statusData.status)) break;
          } catch (e: any) {
            lines.push(`  [${i+1}] 轮询失败: ${e?.message || e}`);
            break;
          }
        }
      }
    } catch (e: any) {
      lines.push(`完整流程失败: ${e?.message || e}`);
    }

    const diagText = lines.join('\n');
    setBackendDiag(diagText);
    console.log('[BackendDiag]\n' + diagText);

    const hasHealthOk = lines.some(l => l.includes('"status":"ok"'));
    const has200 = lines.some(l => l.includes('状态: 200'));
    setBackendAvailable(hasHealthOk && has200);
    return diagText;
  }, []);

  const getCurrentBuffer = useCallback(() => {
    if (playMode === 'original' || !processedAudioBuffer) return audioBuffer;
    return processedAudioBuffer;
  }, [playMode, audioBuffer, processedAudioBuffer]);

  const play = useCallback(() => {
    const buffer = getCurrentBuffer();
    if (!buffer) return;

    const context = getAudioContext();
    if (context.state === 'suspended') {
      context.resume();
    }

    if (sourceNodeRef.current) {
      stopPlaying();
    }

    const source = context.createBufferSource();
    const gain = context.createGain();

    source.buffer = buffer;
    source.connect(gain);
    gain.connect(analyserRef.current!);
    analyserRef.current!.connect(context.destination);

    gain.gain.value = 1.0;

    sourceNodeRef.current = source;
    gainNodeRef.current = gain;

    startTimeRef.current = context.currentTime - pausedAtRef.current;
    source.start(0, pausedAtRef.current);

    isPlayingRef.current = true;
    setIsPlaying(true);

    const updateTime = () => {
      if (isPlayingRef.current) {
        const current = context.currentTime - startTimeRef.current;
        if (current >= buffer.duration) {
          stopPlaying();
          setCurrentTime(0);
          pausedAtRef.current = 0;
        } else {
          setCurrentTime(current);
          animationFrameRef.current = requestAnimationFrame(updateTime);
        }
      }
    };
    updateTime();

    source.onended = () => {
      if (isPlayingRef.current) {
        stopPlaying();
        setCurrentTime(0);
        pausedAtRef.current = 0;
      }
    };
  }, [getCurrentBuffer, getAudioContext, stopPlaying]);

  const pause = useCallback(() => {
    pausedAtRef.current = currentTime;
    stopPlaying();
  }, [currentTime, stopPlaying]);

  const seek = useCallback((time: number) => {
    const wasPlaying = isPlayingRef.current;
    if (isPlayingRef.current) {
      stopPlaying();
    }
    pausedAtRef.current = time;
    setCurrentTime(time);
    if (wasPlaying) {
      play();
    }
  }, [stopPlaying, play]);

  const togglePlayMode = useCallback(() => {
    if (!hasBeenProcessed) return;
    const newMode = playMode === 'original' ? 'processed' : 'original';
    setPlayMode(newMode);

    if (isPlayingRef.current) {
      const currentPosition = currentTime;
      stopPlaying();
      pausedAtRef.current = currentPosition;
      setCurrentTime(currentPosition);
      play();
    }
  }, [playMode, hasBeenProcessed, currentTime, stopPlaying, play]);

  const downloadProcessedAudio = useCallback(async () => {
    if (!hasBeenProcessed) return;

    const fileName = audioFile
      ? `${audioFile.name.replace(/\.[^/.]+$/, '')}_repaired.wav`
      : 'repaired_audio.wav';

    if (backendAvailable && taskId) {
      try {
        const url = getDownloadUrl(taskId);
        const res = await fetch(url);
        if (!res.ok) throw new Error('下载失败');
        const blob = await res.blob();
        const blobUrl = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = blobUrl;
        a.download = fileName;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(blobUrl);
      } catch {
        if (processedAudioBuffer) {
          try {
            const wavData = await encodeWavWithWorker(processedAudioBuffer, processingOptions.bitDepth);
            const blob = new Blob([wavData], { type: 'audio/wav' });
            const blobUrl = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = blobUrl;
            a.download = fileName;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(blobUrl);
          } catch {
            const wav = await audioBufferToWav(processedAudioBuffer, {
              sampleRate: processedAudioBuffer.sampleRate,
              bitDepth: processingOptions.bitDepth,
            });
            const blob = new Blob([wav], { type: 'audio/wav' });
            const blobUrl = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = blobUrl;
            a.download = fileName;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(blobUrl);
          }
        }
      }
    } else if (processedAudioBuffer) {
      try {
        const wavData = await encodeWavWithWorker(processedAudioBuffer, processingOptions.bitDepth);
        const blob = new Blob([wavData], { type: 'audio/wav' });
        const blobUrl = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = blobUrl;
        a.download = fileName;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(blobUrl);
      } catch {
        const wav = await audioBufferToWav(processedAudioBuffer, {
          sampleRate: processedAudioBuffer.sampleRate,
          bitDepth: processingOptions.bitDepth,
        });
        const blob = new Blob([wav], { type: 'audio/wav' });
        const blobUrl = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = blobUrl;
        a.download = fileName;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(blobUrl);
      }
    }
  }, [hasBeenProcessed, backendAvailable, taskId, processedAudioBuffer, audioFile, processingOptions.bitDepth, encodeWavWithWorker]);

  useEffect(() => {
    return () => {
      stopPlaying();
    };
  }, [stopPlaying]);

  const originalSampleRate = audioBuffer?.sampleRate ?? 0;
  const currentSampleRate = hasBeenProcessed
    ? (processedAudioBuffer?.sampleRate ?? originalSampleRate)
    : originalSampleRate;

  return {
    audioFile,
    audioBuffer,
    processedAudioBuffer,
    isPlaying,
    currentTime,
    duration,
    isProcessing,
    processingProgress,
    processingStep,
    params,
    audioAnalysis,
    selectedMode,
    playMode,
    repairModes,
    processingOptions,
    originalAIDetection,
    processedAIDetection,
    hasBeenProcessed,
    originalSampleRate,
    currentSampleRate,
    backendAvailable,
    backendDiag,
    runBackendDiag,
    wavInfo,
    repairResult,
    loadAudioFile,
    play,
    pause,
    seek,
    updateParam,
    resetParams,
    applyRepairMode,
    applySettings,
    runAIDetection,
    togglePlayMode,
    setProcessingOptions: updateProcessingOptions,
    downloadProcessedAudio,
    analyserRef,
  };
}

async function audioBufferToWav(buffer: AudioBuffer, options: { sampleRate: number; bitDepth: 16 | 24 | 32 }): Promise<ArrayBuffer> {
  const numChannels = buffer.numberOfChannels;
  const targetSampleRate = options.sampleRate;
  const bitDepth = options.bitDepth;

  const bytesPerSample = bitDepth / 8;
  const blockAlign = numChannels * bytesPerSample;
  const dataLength = buffer.length * blockAlign;
  const bufferLength = 44 + dataLength;

  const arrayBuffer = new ArrayBuffer(bufferLength);
  const view = new DataView(arrayBuffer);

  writeString(view, 0, 'RIFF');
  view.setUint32(4, 36 + dataLength, true);
  writeString(view, 8, 'WAVE');
  writeString(view, 12, 'fmt ');
  view.setUint32(16, 16, true);
  view.setUint16(20, 1, true);
  view.setUint16(22, numChannels, true);
  view.setUint32(24, targetSampleRate, true);
  view.setUint32(28, targetSampleRate * blockAlign, true);
  view.setUint16(32, blockAlign, true);
  view.setUint16(34, bitDepth, true);
  writeString(view, 36, 'data');
  view.setUint32(40, dataLength, true);

  const channels: Float32Array[] = [];
  for (let i = 0; i < numChannels; i++) {
    channels.push(buffer.getChannelData(i));
  }

  let offset = 44;
  for (let i = 0; i < buffer.length; i++) {
    for (let ch = 0; ch < numChannels; ch++) {
      const sample = Math.max(-1, Math.min(1, channels[ch][i]));

      if (bitDepth === 16) {
        view.setInt16(offset, sample < 0 ? sample * 0x8000 : sample * 0x7fff, true);
        offset += 2;
      } else if (bitDepth === 24) {
        const intSample = sample < 0 ? sample * 0x800000 : sample * 0x7fffff;
        const data = intSample & 0x00ffffff;
        view.setUint8(offset, data & 0xff);
        view.setUint8(offset + 1, (data >> 8) & 0xff);
        view.setUint8(offset + 2, (data >> 16) & 0xff);
        offset += 3;
      } else if (bitDepth === 32) {
        view.setInt32(offset, sample < 0 ? sample * 0x80000000 : sample * 0x7fffffff, true);
        offset += 4;
      }
    }
  }

  return arrayBuffer;
}

function writeString(view: DataView, offset: number, string: string) {
  for (let i = 0; i < string.length; i++) {
    view.setUint8(offset + i, string.charCodeAt(i));
  }
}

function createValidWavBlob(durationSec: number, sampleRate: number, frequency: number): Blob {
  const numChannels = 1;
  const numSamples = Math.floor(sampleRate * durationSec);
  const bytesPerSample = 2;
  const blockAlign = numChannels * bytesPerSample;
  const dataLength = numSamples * blockAlign;
  const bufferLength = 44 + dataLength;

  const arrayBuffer = new ArrayBuffer(bufferLength);
  const view = new DataView(arrayBuffer);

  writeString(view, 0, 'RIFF');
  view.setUint32(4, 36 + dataLength, true);
  writeString(view, 8, 'WAVE');
  writeString(view, 12, 'fmt ');
  view.setUint32(16, 16, true);
  view.setUint16(20, 1, true);
  view.setUint16(22, numChannels, true);
  view.setUint32(24, sampleRate, true);
  view.setUint32(28, sampleRate * blockAlign, true);
  view.setUint16(32, blockAlign, true);
  view.setUint16(34, bytesPerSample * 8, true);
  writeString(view, 36, 'data');
  view.setUint32(40, dataLength, true);

  let offset = 44;
  for (let i = 0; i < numSamples; i++) {
    const t = i / sampleRate;
    const sample = Math.sin(2 * Math.PI * frequency * t) * 0.3;
    const intSample = Math.max(-32768, Math.min(32767, Math.round(sample * 32767)));
    view.setInt16(offset, intSample, true);
    offset += 2;
  }

  return new Blob([arrayBuffer], { type: 'audio/wav' });
}

async function applyDeEssing(buffer: AudioBuffer, intensity: number): Promise<AudioBuffer> {
  const ctx = new OfflineAudioContext(
    buffer.numberOfChannels,
    buffer.length,
    buffer.sampleRate
  );

  const source = ctx.createBufferSource();
  source.buffer = buffer;

  const band4k = ctx.createBiquadFilter();
  band4k.type = 'bandpass';
  band4k.frequency.value = 4000;
  band4k.Q.value = 2;

  const band6k = ctx.createBiquadFilter();
  band6k.type = 'bandpass';
  band6k.frequency.value = 6000;
  band6k.Q.value = 2;

  const band8k = ctx.createBiquadFilter();
  band8k.type = 'bandpass';
  band8k.frequency.value = 8000;
  band8k.Q.value = 2;

  const comp4k = ctx.createDynamicsCompressor();
  comp4k.threshold.value = -35 + intensity * 10;
  comp4k.knee.value = 30;
  comp4k.ratio.value = 2 + intensity * 4;
  comp4k.attack.value = 0.001;
  comp4k.release.value = 0.05;

  const comp6k = ctx.createDynamicsCompressor();
  comp6k.threshold.value = -35 + intensity * 10;
  comp6k.knee.value = 30;
  comp6k.ratio.value = 2 + intensity * 4;
  comp6k.attack.value = 0.001;
  comp6k.release.value = 0.05;

  const comp8k = ctx.createDynamicsCompressor();
  comp8k.threshold.value = -35 + intensity * 10;
  comp8k.knee.value = 30;
  comp8k.ratio.value = 2 + intensity * 4;
  comp8k.attack.value = 0.001;
  comp8k.release.value = 0.05;

  const mergeGain4k = ctx.createGain();
  mergeGain4k.gain.value = 0.3 * intensity;

  const mergeGain6k = ctx.createGain();
  mergeGain6k.gain.value = 0.4 * intensity;

  const mergeGain8k = ctx.createGain();
  mergeGain8k.gain.value = 0.3 * intensity;

  const dryGain = ctx.createGain();
  dryGain.gain.value = 1;

  source.connect(dryGain);
  dryGain.connect(ctx.destination);

  source.connect(band4k);
  band4k.connect(comp4k);
  comp4k.connect(mergeGain4k);
  mergeGain4k.connect(ctx.destination);

  source.connect(band6k);
  band6k.connect(comp6k);
  comp6k.connect(mergeGain6k);
  mergeGain6k.connect(ctx.destination);

  source.connect(band8k);
  band8k.connect(comp8k);
  comp8k.connect(mergeGain8k);
  mergeGain8k.connect(ctx.destination);

  source.start();

  return ctx.startRendering();
}

async function applyPresenceBoost(buffer: AudioBuffer, intensity: number): Promise<AudioBuffer> {
  const ctx = new OfflineAudioContext(
    buffer.numberOfChannels,
    buffer.length,
    buffer.sampleRate
  );

  const source = ctx.createBufferSource();
  source.buffer = buffer;

  const eq2500 = ctx.createBiquadFilter();
  eq2500.type = 'peaking';
  eq2500.frequency.value = 2500;
  eq2500.Q.value = 1.2;
  eq2500.gain.value = intensity * 2.5;

  const eq3500 = ctx.createBiquadFilter();
  eq3500.type = 'peaking';
  eq3500.frequency.value = 3500;
  eq3500.Q.value = 1.0;
  eq3500.gain.value = intensity * 4;

  const eq5000 = ctx.createBiquadFilter();
  eq5000.type = 'peaking';
  eq5000.frequency.value = 5000;
  eq5000.Q.value = 1.4;
  eq5000.gain.value = intensity * 2;

  source.connect(eq2500);
  eq2500.connect(eq3500);
  eq3500.connect(eq5000);
  eq5000.connect(ctx.destination);

  source.start();

  return ctx.startRendering();
}

async function applyBassEnhance(buffer: AudioBuffer, intensity: number): Promise<AudioBuffer> {
  const ctx = new OfflineAudioContext(
    buffer.numberOfChannels,
    buffer.length,
    buffer.sampleRate
  );

  const source = ctx.createBufferSource();
  source.buffer = buffer;

  const subBass = ctx.createBiquadFilter();
  subBass.type = 'peaking';
  subBass.frequency.value = 60;
  subBass.Q.value = 0.8;
  subBass.gain.value = intensity * 4;

  const bassWarmth = ctx.createBiquadFilter();
  bassWarmth.type = 'peaking';
  bassWarmth.frequency.value = 150;
  bassWarmth.Q.value = 0.7;
  bassWarmth.gain.value = intensity * 3;

  source.connect(subBass);
  subBass.connect(bassWarmth);
  bassWarmth.connect(ctx.destination);

  source.start();

  return ctx.startRendering();
}
