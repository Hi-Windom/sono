import React, { useState } from 'react';
import { Header } from '../components/Header';
import { AudioUploader } from '../components/AudioUploader';
import { AudioPlayer } from '../components/AudioPlayer';
import { WaveformVisualizer } from '../components/WaveformVisualizer';
import { SpectrumVisualizer } from '../components/SpectrumVisualizer';
import { AIRepairPanel } from '../components/AIRepairPanel';
import { DownloadButton } from '../components/DownloadButton';
import { AIDetectionComparison } from '../components/AIDetectionComparison';
import { useAudioProcessor } from '../hooks/useAudioProcessor';

export default function Home() {
  const {
    audioFile,
    audioBuffer,
    processedAudioBuffer,
    isPlaying,
    currentTime,
    duration,
    isProcessing,
    processingProgress,
    processingStep,
    params,
    audioAnalysis,
    selectedMode,
    playMode,
    repairModes,
    processingOptions,
    originalAIDetection,
    processedAIDetection,
    hasBeenProcessed,
    originalSampleRate,
    currentSampleRate,
    backendAvailable,
    backendDiag,
    runBackendDiag,
    wavInfo,
    repairResult,
    loadAudioFile,
    play,
    pause,
    seek,
    updateParam,
    resetParams,
    applyRepairMode,
    applySettings,
    runAIDetection,
    togglePlayMode,
    setProcessingOptions,
    downloadProcessedAudio,
    analyserRef,
  } = useAudioProcessor();

  const [showDiag, setShowDiag] = useState(false);

  return (
    <div className="min-h-screen bg-dark py-6">
      <Header />
      
      <div className="container mx-auto px-4 py-8 max-w-7xl">
        {!audioFile ? (
          <div className="flex flex-col items-center justify-center py-20">
            <div className="mb-4 text-sm">
              <span
                className={backendAvailable ? 'text-green-400' : 'text-yellow-400'}
                style={{ cursor: 'pointer', textDecoration: 'underline' }}
                onClick={async () => { await runBackendDiag(); setShowDiag(true); }}
              >
                {backendAvailable ? '● 后端已连接' : '● 后端不可用(点击诊断)'}
              </span>
            </div>
            <AudioUploader onFileSelect={loadAudioFile} />
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <div className="lg:col-span-7 space-y-6">
              <div className="bg-primary/50 border border-white/10 rounded-xl p-6">
                <div className="flex items-center justify-between mb-6">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 bg-gradient-to-br from-cyan-500/20 to-purple-500/20 rounded-lg flex items-center justify-center border border-cyan-400/20">
                      <svg className="w-6 h-6 text-cyan-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19V6l12-3v13M9 19c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zm12-3c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2z" />
                      </svg>
                    </div>
                    <div>
                      <h3 className="text-white font-semibold text-lg truncate max-w-[300px]">
                        {audioFile.name}
                      </h3>
                      <p className="text-gray-400 text-sm">
                        {(audioFile.size / (1024 * 1024)).toFixed(2)} MB
                        {' • '}
                        {originalSampleRate/1000} kHz
                        {wavInfo && ` • ${wavInfo.bitDepth}bit`}
                        {' • '}
                        {audioBuffer ? (audioBuffer.numberOfChannels === 1 ? '单声道' : '立体声') : ''}
                        {hasBeenProcessed && (
                          <span className="text-green-400 ml-2">✓ 已修复</span>
                        )}
                        {' • '}
                        <span
                          className={backendAvailable ? 'text-green-400' : 'text-yellow-400'}
                          style={{ cursor: 'pointer', textDecoration: 'underline' }}
                          onClick={async () => { await runBackendDiag(); setShowDiag(true); }}
                        >
                          {backendAvailable ? '后端已连接' : '后端不可用(点击诊断)'}
                        </span>
                      </p>
                    </div>
                  </div>
                </div>
                
                <AudioPlayer
                  isPlaying={isPlaying}
                  currentTime={currentTime}
                  duration={duration}
                  playMode={playMode}
                  onPlay={play}
                  onPause={pause}
                  onSeek={seek}
                  onTogglePlayMode={togglePlayMode}
                />
                
                {isPlaying && analyserRef.current && (
                  <div className="mt-6">
                    <SpectrumVisualizer 
                      analyser={analyserRef.current} 
                      color={playMode === 'original' ? '#6B7280' : '#00D9FF'} 
                      label={playMode === 'original' ? '原始频谱' : '修复后频谱'} 
                    />
                  </div>
                )}
                
                {audioBuffer && (
                  <div className="mt-6">
                    <WaveformVisualizer 
                      audioBuffer={hasBeenProcessed && playMode === 'processed' && processedAudioBuffer ? processedAudioBuffer : audioBuffer} 
                      label={playMode === 'processed' && hasBeenProcessed ? '修复后波形' : '原始波形'}
                      currentTime={currentTime}
                      duration={duration}
                      onSeek={seek}
                    />
                  </div>
                )}

                {isProcessing && (
                  <div className="mt-6">
                    <div className="flex items-center gap-2 mb-2">
                      <div className="w-4 h-4 bg-gradient-to-r from-cyan-500 to-purple-500 rounded-full animate-spin" />
                      <span className="text-cyan-400 text-sm">{processingStep || '正在处理音频...'}</span>
                    </div>
                    <div className="w-full h-2 bg-gray-700 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-gradient-to-r from-cyan-500 via-purple-500 to-yellow-500 transition-all duration-300"
                        style={{ width: `${processingProgress * 100}%` }}
                      />
                    </div>
                    <div className="text-right text-gray-400 text-xs mt-1">
                      {Math.round(processingProgress * 100)}%
                    </div>
                  </div>
                )}
              </div>

              <AIDetectionComparison
                before={originalAIDetection}
                after={processedAIDetection}
                onDetect={runAIDetection}
                isProcessing={isProcessing}
              />
            </div>
            
            <div className="lg:col-span-5 space-y-6">
              <AIRepairPanel
                params={params}
                analysis={audioAnalysis}
                selectedMode={selectedMode}
                modes={repairModes}
                processingOptions={processingOptions}
                onParamChange={updateParam}
                onReset={resetParams}
                onModeSelect={applyRepairMode}
                onApply={applySettings}
                onOptionsChange={setProcessingOptions}
                disabled={isProcessing}
              />
              
              <DownloadButton
                disabled={!hasBeenProcessed}
                onDownload={downloadProcessedAudio}
                hasBeenProcessed={hasBeenProcessed}
                repairResult={repairResult}
                audioFileName={audioFile?.name}
              />
            </div>
          </div>
        )}
      </div>

      {showDiag && (
        <div
          style={{
            position: 'fixed', bottom: 0, left: 0, right: 0,
            background: 'rgba(0,0,0,0.95)', color: '#0f0',
            fontFamily: 'monospace', fontSize: 12,
            padding: 16, zIndex: 9999, maxHeight: '50vh', overflow: 'auto',
            borderTop: '2px solid #0f0',
          }}
        >
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
            <span style={{ color: '#0f0', fontWeight: 'bold' }}>后端连接诊断</span>
            <button
              onClick={() => setShowDiag(false)}
              style={{ color: '#f00', background: 'none', border: 'none', cursor: 'pointer', fontSize: 16 }}
            >✕ 关闭</button>
          </div>
          <pre style={{ whiteSpace: 'pre-wrap', margin: 0 }}>{backendDiag}</pre>
          <button
            onClick={runBackendDiag}
            style={{
              marginTop: 8, padding: '4px 12px',
              background: '#0f0', color: '#000', border: 'none',
              cursor: 'pointer', fontWeight: 'bold',
            }}
          >重新检测</button>
        </div>
      )}
    </div>
  );
}
