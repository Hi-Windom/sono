import { AIRepairParams } from '../utils/advancedAudioProcessing';
import { AISongDetectionResult } from '../utils/aiSongChecker';

export interface ProcessingOptions {
  sampleRate: number;
  bitDepth: 16 | 24 | 32;
}

const API_BASE = '/api/v1';
const HEALTH_URL = '/health';

const LOG_ENABLED = true;
function log(tag: string, ...args: unknown[]) {
  if (!LOG_ENABLED) return;
  const ts = new Date().toISOString().substr(11, 12);
  const msg = `[${ts}][backendApi][${tag}] ${args.map(a => typeof a === 'object' ? JSON.stringify(a) : String(a)).join(' ')}`;
  console.log(msg);
}

interface UploadResponse {
  task_id: string;
  filename: string;
  size: number;
  message: string;
}

interface TaskStatus {
  task_id: string;
  status: string;
  progress: number;
  step: string;
  detection_result?: BackendDetectionResult;
  repaired_detection_result?: BackendDetectionResult;
  repair_result?: BackendRepairResult;
  error?: string;
}

interface BackendDetectionResult {
  is_ai_generated: boolean;
  confidence: number;
  ai_probability: number;
  reasons: string[];
  features: Record<string, number>;
  sample_rate: number;
  duration: number;
  detect_type?: string;
}

interface BackendRepairResult {
  issues_found: string[];
  original_sample_rate: number;
  output_sample_rate: number;
  output_bit_depth: number;
  duration: number;
  channels: number;
}

interface ProgressEvent {
  task_id: string;
  status: string;
  progress: number;
  step: string;
  detection_result?: BackendDetectionResult;
  repaired_detection_result?: BackendDetectionResult;
  repair_result?: BackendRepairResult;
  error?: string;
}

function mapParamsToBackend(params: AIRepairParams, options: ProcessingOptions): Record<string, unknown> {
  return {
    de_clipping: params.deClipping,
    noise_reduction: params.noiseReduction,
    de_essing: params.deEssing,
    de_crackle: params.deCrackle,
    de_pop: params.dePop,
    harmonic_enhance: params.harmonicEnhance,
    dynamic_range: params.dynamicRange,
    softness: params.softness,
    presence_boost: params.presenceBoost,
    bass_enhance: params.bassEnhance,
    spatial_enhance: params.spatialEnhance,
    transient_repair: params.transientRepair,
    sample_rate: options.sampleRate,
    bit_depth: options.bitDepth,
  };
}

function mapDetectionResult(backend: BackendDetectionResult): AISongDetectionResult {
  const aiProbability = backend.ai_probability;
  const humanProbability = 1 - aiProbability;
  const isAI = aiProbability > 0.5;

  let signature: AISongDetectionResult['signature'] = 'uncertain';
  if (aiProbability > 0.7 && backend.confidence > 0.4) {
    signature = 'ai';
  } else if (humanProbability > 0.7 && backend.confidence > 0.4) {
    signature = 'human';
  } else if (backend.confidence > 0.3) {
    signature = 'mixed';
  }

  const f = backend.features || {};

  return {
    isAI,
    aiProbability,
    humanProbability,
    confidence: backend.confidence,
    features: {
      spectralFlatness: f.spectral_flatness ?? 0,
      spectralCentroid: f.spectral_centroid_mean ?? 0,
      spectralBandwidth: 0,
      spectralRolloff: 0,
      zeroCrossingRate: 0,
      energy: 0,
      energyEntropy: 0,
      harmonicSpectralCentroid: 0,
      onsetRate: 0,
      pitchVariability: f.pitch_variability ?? 0,
      vibratoRate: 0,
      vibratoDepth: 0,
      formantStability: 0,
      noiseFloor: 0,
      dynamicRange: f.dynamic_range ?? 0,
      temporalCentroid: 0,
      spectralFlux: 0,
      spectralEntropy: f.spectral_entropy ?? 0,
      mfccSimilarity: f.mfcc_variability ?? 0,
      microRhythmConsistency: f.micro_rhythm_consistency ?? 0,
      harmonicRatio: 0,
      highFreqAttenuation: f.high_freq_attenuation ?? 0,
      temporalRegularity: f.temporal_regularity ?? 0,
    },
    reasons: backend.reasons || [],
    signature,
  };
}

export async function uploadAudio(file: File): Promise<UploadResponse> {
  const url = `${API_BASE}/upload`;
  log('upload', `POST ${url} file=${file.name} size=${file.size}`);

  const formData = new FormData();
  formData.append('file', file);

  try {
    const res = await fetch(url, {
      method: 'POST',
      body: formData,
    });

    log('upload', `response status=${res.status} ok=${res.ok}`);

    if (!res.ok) {
      const err = await res.json().catch(() => ({ detail: '上传失败' }));
      log('upload', `ERROR: ${err.detail}`);
      throw new Error(err.detail || '上传失败');
    }

    const data = await res.json();
    log('upload', `success task_id=${data.task_id}`);
    return data;
  } catch (e) {
    log('upload', `FETCH ERROR: ${e instanceof Error ? e.message : String(e)}`);
    throw e;
  }
}

export async function detectAudio(taskId: string, type: 'original' | 'repaired' = 'original'): Promise<{ task_id: string; message: string }> {
  const url = `${API_BASE}/detect`;
  log('detect', `POST ${url} task_id=${taskId} type=${type}`);

  try {
    const res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ task_id: taskId, type }),
    });

    log('detect', `response status=${res.status} ok=${res.ok}`);

    if (!res.ok) {
      const err = await res.json().catch(() => ({ detail: '检测请求失败' }));
      log('detect', `ERROR: ${err.detail}`);
      throw new Error(err.detail || '检测请求失败');
    }

    const data = await res.json();
    log('detect', `success: ${data.message}`);
    return data;
  } catch (e) {
    log('detect', `FETCH ERROR: ${e instanceof Error ? e.message : String(e)}`);
    throw e;
  }
}

export async function repairAudio(taskId: string, params: AIRepairParams, options: ProcessingOptions): Promise<{ task_id: string; message: string }> {
  const url = `${API_BASE}/repair`;
  const backendParams = mapParamsToBackend(params, options);
  log('repair', `POST ${url} task_id=${taskId}`);

  try {
    const res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ task_id: taskId, params: backendParams }),
    });

    log('repair', `response status=${res.status} ok=${res.ok}`);

    if (!res.ok) {
      const err = await res.json().catch(() => ({ detail: '修复请求失败' }));
      log('repair', `ERROR: ${err.detail}`);
      throw new Error(err.detail || '修复请求失败');
    }

    const data = await res.json();
    log('repair', `success: ${data.message}`);
    return data;
  } catch (e) {
    log('repair', `FETCH ERROR: ${e instanceof Error ? e.message : String(e)}`);
    throw e;
  }
}

export async function getTaskStatus(taskId: string): Promise<TaskStatus> {
  const url = `${API_BASE}/status/${taskId}`;

  try {
    const res = await fetch(url);

    if (!res.ok) {
      let detail = `获取任务状态失败 (HTTP ${res.status})`;
      try {
        const body = await res.json();
        if (body.detail) detail = body.detail;
      } catch {}
      log('status', `ERROR: ${detail} url=${url}`);
      throw new Error(detail);
    }

    const data = await res.json();
    log('status', `task_id=${taskId} status=${data.status} progress=${data.progress} step=${data.step}`);
    return data;
  } catch (e) {
    if (!(e instanceof Error && e.message.includes('HTTP'))) {
      log('status', `FETCH ERROR: ${e instanceof Error ? e.message : String(e)} url=${url}`);
    }
    throw e;
  }
}

const DEFAULT_TERMINAL_STATES = new Set(['completed', 'detected', 'error']);

export function pollProgress(
  taskId: string,
  onProgress: (event: ProgressEvent) => void,
  onError?: (error: Error) => void,
  onComplete?: (event: ProgressEvent) => void,
  terminalStates?: Set<string>,
): AbortController {
  const controller = new AbortController();
  let stopped = false;
  let consecutiveErrors = 0;
  const MAX_ERRORS = 5;
  const terminals = terminalStates || DEFAULT_TERMINAL_STATES;

  log('poll', `START task_id=${taskId} terminals=[${[...terminals].join(',')}]`);

  const poll = async () => {
    while (!stopped) {
      try {
        const status = await getTaskStatus(taskId);
        consecutiveErrors = 0;
        onProgress(status);

        if (terminals.has(status.status)) {
          log('poll', `COMPLETE task_id=${taskId} status=${status.status}`);
          onComplete?.(status);
          return;
        }
      } catch (err) {
        if (stopped) return;
        consecutiveErrors++;
        log('poll', `ERROR #${consecutiveErrors} task_id=${taskId}: ${err instanceof Error ? err.message : String(err)}`);
        if (consecutiveErrors >= MAX_ERRORS) {
          log('poll', `GIVING UP after ${MAX_ERRORS} errors`);
          onError?.(err instanceof Error ? err : new Error(String(err)));
          return;
        }
      }

      await new Promise<void>((resolve) => {
        const timer = setTimeout(resolve, 800);
        controller.signal.addEventListener('abort', () => {
          clearTimeout(timer);
          stopped = true;
          resolve();
        }, { once: true });
      });

      if (stopped) return;
    }
  };

  poll();

  return controller;
}

export function getDownloadUrl(taskId: string): string {
  return `${API_BASE}/download/${taskId}`;
}

export function getPreviewUrl(taskId: string, type: 'original' | 'repaired'): string {
  return `${API_BASE}/preview/${taskId}?type=${type}`;
}

export async function checkBackendHealth(): Promise<boolean> {
  log('health', `GET ${HEALTH_URL}`);
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 5000);
    const res = await fetch(HEALTH_URL, { signal: controller.signal });
    clearTimeout(timeoutId);
    log('health', `response status=${res.status} ok=${res.ok}`);
    return res.ok;
  } catch (e) {
    log('health', `FAILED: ${e instanceof Error ? e.message : String(e)}`);
    return false;
  }
}

export { mapDetectionResult, type BackendDetectionResult, type BackendRepairResult, type ProgressEvent, type TaskStatus };
