import os
import json
import asyncio
from fastapi import APIRouter, UploadFile, File, HTTPException, Query
from fastapi.responses import FileResponse, StreamingResponse
from pydantic import BaseModel
from typing import Optional

from config import UPLOAD_DIR, OUTPUT_DIR, ALLOWED_EXTENSIONS, MAX_UPLOAD_SIZE
from database import create_task, get_task
from services.task_manager import generate_task_id, submit_detect_task, submit_repair_task

router = APIRouter(prefix="/api/v1")

class RepairRequest(BaseModel):
    task_id: str
    params: dict

class DetectRequest(BaseModel):
    task_id: str
    type: str = "original"

@router.post("/upload")
async def upload_audio(file: UploadFile = File(...)):
    ext = os.path.splitext(file.filename)[1].lower()
    if ext not in ALLOWED_EXTENSIONS:
        raise HTTPException(400, f"不支持的格式: {ext}，支持: {', '.join(ALLOWED_EXTENSIONS)}")

    task_id = generate_task_id()
    filepath = os.path.join(UPLOAD_DIR, f"{task_id}{ext}")

    total_size = 0
    with open(filepath, "wb") as f:
        while True:
            chunk = await file.read(1024 * 1024)
            if not chunk:
                break
            total_size += len(chunk)
            if total_size > MAX_UPLOAD_SIZE:
                os.remove(filepath)
                raise HTTPException(400, f"文件过大，最大支持 {MAX_UPLOAD_SIZE // 1024 // 1024}MB")
            f.write(chunk)

    create_task(task_id, file.filename, filepath, {})

    return {
        "task_id": task_id,
        "filename": file.filename,
        "size": total_size,
        "message": "上传成功"
    }

@router.post("/detect")
async def detect_audio(request: DetectRequest):
    task = get_task(request.task_id)
    if not task:
        raise HTTPException(404, "任务不存在")

    if request.type == "repaired":
        audio_path = task.get("output_path", "")
        if not audio_path or not os.path.exists(audio_path):
            raise HTTPException(400, "修复文件不存在，请先完成修复")
    else:
        audio_path = task["original_path"]
        if not os.path.exists(audio_path):
            raise HTTPException(400, "音频文件不存在")

    submit_detect_task(request.task_id, audio_path, request.type)

    return {
        "task_id": request.task_id,
        "message": "检测任务已提交"
    }

@router.post("/repair")
async def repair_audio(request: RepairRequest):
    task = get_task(request.task_id)
    if not task:
        raise HTTPException(404, "任务不存在")

    if not os.path.exists(task["original_path"]):
        raise HTTPException(400, "音频文件不存在")

    from database import update_task
    update_task(request.task_id, params=request.params)

    submit_repair_task(request.task_id, task["original_path"], request.params)

    return {
        "task_id": request.task_id,
        "message": "修复任务已提交"
    }

@router.get("/status/{task_id}")
async def task_status(task_id: str):
    task = get_task(task_id)
    if not task:
        raise HTTPException(404, "任务不存在")

    return {
        "task_id": task_id,
        "status": task["status"],
        "progress": task["progress"],
        "step": task["step"],
        "detection_result": task.get("detection_result"),
        "repaired_detection_result": task.get("repaired_detection_result"),
        "repair_result": task.get("repair_result"),
        "error": task.get("error"),
    }

@router.get("/stream/{task_id}")
async def stream_progress(task_id: str):
    task = get_task(task_id)
    if not task:
        raise HTTPException(404, "任务不存在")

    async def event_generator():
        while True:
            t = get_task(task_id)
            if t is None:
                break
            data = {
                "task_id": task_id,
                "status": t["status"],
                "progress": t["progress"],
                "step": t["step"],
            }
            if t.get("detection_result"):
                data["detection_result"] = t["detection_result"]
            if t.get("repaired_detection_result"):
                data["repaired_detection_result"] = t["repaired_detection_result"]
            if t.get("repair_result"):
                data["repair_result"] = t["repair_result"]
            if t.get("error"):
                data["error"] = t["error"]

            yield f"data: {json.dumps(data, ensure_ascii=False)}\n\n"

            if t["status"] in ("completed", "detected", "error"):
                break
            await asyncio.sleep(0.3)

    return StreamingResponse(event_generator(), media_type="text/event-stream")

@router.get("/download/{task_id}")
async def download_audio(task_id: str):
    task = get_task(task_id)
    if not task:
        raise HTTPException(404, "任务不存在")

    output_path = task.get("output_path", "")
    if not output_path or not os.path.exists(output_path):
        raise HTTPException(400, "修复文件不存在，请先完成修复")

    filename = os.path.basename(task["original_filename"])
    base_name = os.path.splitext(filename)[0]
    download_name = f"{base_name}_repaired.wav"

    return FileResponse(
        output_path,
        media_type="audio/wav",
        filename=download_name,
        headers={
            "Content-Length": str(os.path.getsize(output_path)),
        },
    )

@router.get("/preview/{task_id}")
async def preview_audio(task_id: str, type: str = Query("original")):
    task = get_task(task_id)
    if not task:
        raise HTTPException(404, "任务不存在")

    if type == "original":
        filepath = task["original_path"]
    elif type == "repaired":
        filepath = task.get("output_path", "")
        if not filepath or not os.path.exists(filepath):
            raise HTTPException(400, "修复文件不存在，请先完成修复")
    else:
        raise HTTPException(400, "type必须是original或repaired")

    if not os.path.exists(filepath):
        raise HTTPException(404, "文件不存在")

    return FileResponse(
        filepath,
        media_type="audio/wav",
        headers={
            "Cache-Control": "public, max-age=3600",
            "Content-Length": str(os.path.getsize(filepath)),
        },
    )
