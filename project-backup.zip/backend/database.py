import sqlite3
import json
from config import DB_PATH

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db()
    conn.execute("""
        CREATE TABLE IF NOT EXISTS tasks (
            id TEXT PRIMARY KEY,
            status TEXT NOT NULL DEFAULT 'pending',
            progress REAL NOT NULL DEFAULT 0,
            step TEXT NOT NULL DEFAULT '',
            original_filename TEXT NOT NULL DEFAULT '',
            original_path TEXT NOT NULL DEFAULT '',
            output_path TEXT NOT NULL DEFAULT '',
            params TEXT NOT NULL DEFAULT '{}',
            detection_result TEXT,
            repaired_detection_result TEXT,
            repair_result TEXT,
            error TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)
    conn.commit()
    conn.close()

def create_task(task_id: str, filename: str, filepath: str, params: dict):
    conn = get_db()
    conn.execute(
        "INSERT INTO tasks (id, original_filename, original_path, params) VALUES (?, ?, ?, ?)",
        (task_id, filename, filepath, json.dumps(params))
    )
    conn.commit()
    conn.close()

def update_task(task_id: str, **kwargs):
    conn = get_db()
    sets = []
    values = []
    for k, v in kwargs.items():
        sets.append(f"{k} = ?")
        values.append(json.dumps(v) if isinstance(v, (dict, list)) else v)
    sets.append("updated_at = CURRENT_TIMESTAMP")
    values.append(task_id)
    conn.execute(f"UPDATE tasks SET {', '.join(sets)} WHERE id = ?", values)
    conn.commit()
    conn.close()

def get_task(task_id: str) -> dict | None:
    conn = get_db()
    row = conn.execute("SELECT * FROM tasks WHERE id = ?", (task_id,)).fetchone()
    conn.close()
    if row is None:
        return None
    result = dict(row)
    if result.get("params"):
        result["params"] = json.loads(result["params"])
    if result.get("detection_result"):
        result["detection_result"] = json.loads(result["detection_result"])
    if result.get("repaired_detection_result"):
        result["repaired_detection_result"] = json.loads(result["repaired_detection_result"])
    if result.get("repair_result"):
        result["repair_result"] = json.loads(result["repair_result"])
    return result
